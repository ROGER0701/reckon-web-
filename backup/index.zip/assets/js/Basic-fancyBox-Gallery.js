$(function() {
    $(".fancybox").fancybox({
        helpers:  {
            title : {
                type : "inside"
            }
        }
    });
});